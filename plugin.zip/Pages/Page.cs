Hello!

Plugin info: @Model.Plugin.ToString()

@Model.Request.ToString()
@Model.Response.ToString()

@{Model.Log.Info("test");}