function hello()
{
	var arg = args.GetRequestArgument("Html");
	log.Info(arg.ArgumentValue.ToString());
}